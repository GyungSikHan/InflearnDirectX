#include "pch.h"
#include "Game.h"

Game::Game()
{
}

Game::~Game()
{
}

void Game::Init(HWND hWnd)
{
	hwnd = hWnd;
	width = GWinSizeX;
	height = GWinSizeY;

	//TODO
}

void Game::Update()
{
}

void Game::Render()
{
}
