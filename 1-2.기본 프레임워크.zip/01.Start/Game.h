#pragma once

class Game
{
public:
	Game();
	~Game();

public:
	void Init(HWND hWnd);
	void Update();
	void Render();

private:
	HWND hwnd;
	uint32 width = 0;
	uint32 height = 0;

private:
	//DX
};

