#pragma once

class Game
{
public:
	Game();
	~Game();

public:
	void Init(HWND hWnd);
	void Update();
	void Render();

private:
	void RenderBegin();
	void RenderEnd();

private:
	void CreateDeviceAndSpwaChain();
	void CreateRenderTargetView();
	void SetViewport();
private:
	HWND hwnd;
	uint32 width = 0;
	uint32 height = 0;

private:
	//Device & SwapChain
	ComPtr<ID3D11Device> device{};
	ComPtr<ID3D11DeviceContext> deviceContext{};
	ComPtr<IDXGISwapChain> swapChain{};

	//RTV
	ComPtr<ID3D11RenderTargetView> renderTargetView;
	//ID3D11RenderTargetView �츮�� ���� �ĸ� ���۸� �����ϴ� ��ü

	//Misc
	//ȭ���� ũ�⸦ ��������
	D3D11_VIEWPORT viewport;
	float clearColor[4] = { 1.0f,0.5f ,0.5f ,0.5f };
};

